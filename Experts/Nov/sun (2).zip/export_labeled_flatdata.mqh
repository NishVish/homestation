
#ifndef EXPORT_LABELED_FLATDATA_MQH
#define EXPORT_LABELED_FLATDATA_MQH

#define LABELED_FLATDATA_FILENAME "labeled_flatdata.csv"

// Track the last exported completed M1 candle.
datetime last_labeled_exported_m1_time = 0;

// Track the incremental row ID.
long last_labeled_export_id = 0;

//+------------------------------------------------------------------+
//| Append a CSV field                                               |
//+------------------------------------------------------------------+
void AppendLabeledCSVField(string &line, const string value)
{
   if(StringLen(line) > 0)
      line += ",";

   line += value;
}

//+------------------------------------------------------------------+
//| Generate column headers for 20 candles (01 to 20)                |
//+------------------------------------------------------------------+
void AppendLabeledHeaders(string &line, const string timeframe)
{
   for(int i = 0; i < CANDLE_COUNT; i++)
   {
      string index = StringFormat("%02d", i + 1);

      AppendLabeledCSVField(line, timeframe + "_" + index + "_time");
      AppendLabeledCSVField(line, timeframe + "_" + index + "_open");
      AppendLabeledCSVField(line, timeframe + "_" + index + "_high");
      AppendLabeledCSVField(line, timeframe + "_" + index + "_low");
      AppendLabeledCSVField(line, timeframe + "_" + index + "_close");
   }
}

//+------------------------------------------------------------------+
//| Append labeled OHLC values and candle timestamps                 |
//+------------------------------------------------------------------+
void AppendLabeledValues(string &line,
                         const numeric_text &data[],
                         const ohlc_data &real_data[])
{
   for(int i = 0; i < CANDLE_COUNT; i++)
   {
      AppendLabeledCSVField(
         line,
         TimeToString(real_data[i].time, TIME_DATE | TIME_MINUTES)
      );

      AppendLabeledCSVField(line, data[i].open);
      AppendLabeledCSVField(line, data[i].high);
      AppendLabeledCSVField(line, data[i].low);
      AppendLabeledCSVField(line, data[i].close);
   }
}

//+------------------------------------------------------------------+
//| Recover the last exported ID from the existing CSV               |
//+------------------------------------------------------------------+
bool LoadLastLabeledExportID(int file)
{
   if(!FileSeek(file, 0, SEEK_SET))
      return false;

   if(FileSize(file) <= 0)
   {
      last_labeled_export_id = 0;
      return true;
   }

   string contents = "";

   while(!FileIsEnding(file))
   {
      string part = FileReadString(file);

      if(StringLen(contents) > 0)
         contents += "\n";

      contents += part;
   }

   int length = StringLen(contents);

   if(length <= 0)
   {
      last_labeled_export_id = 0;
      return true;
   }

   // Find the last non-empty line.
   int end_pos = length - 1;

   while(end_pos >= 0 &&
         (StringGetCharacter(contents, end_pos) == '\n' ||
          StringGetCharacter(contents, end_pos) == '\r'))
   {
      end_pos--;
   }

   if(end_pos < 0)
   {
      last_labeled_export_id = 0;
      return true;
   }

   int start_pos = end_pos;

   while(start_pos >= 0 &&
         StringGetCharacter(contents, start_pos) != '\n' &&
         StringGetCharacter(contents, start_pos) != '\r')
   {
      start_pos--;
   }

   string last_line = StringSubstr(contents,
                                   start_pos + 1,
                                   end_pos - start_pos);

   int comma_pos = StringFind(last_line, ",");

   if(comma_pos < 0)
   {
      last_labeled_export_id = 0;
      return true;
   }

   string id_text = StringSubstr(last_line, 0, comma_pos);

   if(StringLen(id_text) == 0)
   {
      last_labeled_export_id = 0;
      return true;
   }

   for(int i = 0; i < StringLen(id_text); i++)
   {
      ushort ch = StringGetCharacter(id_text, i);

      if(ch < '0' || ch > '9')
      {
         // Header or invalid ID.
         last_labeled_export_id = 0;
         return true;
      }
   }

   last_labeled_export_id = (long)StringToInteger(id_text);

   return true;
}

//+------------------------------------------------------------------+
//| Export one flattened labeled row                                 |
//+------------------------------------------------------------------+
bool ExportLabeledFlatData()
{
   // Validate all required arrays.
   if(ArraySize(labeled_text_15min) != CANDLE_COUNT ||
      ArraySize(labeled_text_5min)  != CANDLE_COUNT ||
      ArraySize(labeled_text_1min)  != CANDLE_COUNT ||
      ArraySize(real_15min)         != CANDLE_COUNT ||
      ArraySize(real_5min)          != CANDLE_COUNT ||
      ArraySize(real_1min)          != CANDLE_COUNT)
   {
      Print("Labeled export failed: expected ",
            CANDLE_COUNT,
            " candles per timeframe.");

      return false;
   }

   // Latest completed M1 candle timestamp.
   datetime current_m1_time = real_1min[CANDLE_COUNT - 1].time;

   if(current_m1_time == 0)
   {
      Print("Labeled export failed: invalid M1 timestamp.");
      return false;
   }

   // Export only once for each completed M1 candle.
   if(current_m1_time == last_labeled_exported_m1_time)
      return true;

   ResetLastError();

   int file = FileOpen(LABELED_FLATDATA_FILENAME,
                       FILE_READ | FILE_WRITE | FILE_TXT |
                       FILE_ANSI | FILE_SHARE_READ);

   if(file == INVALID_HANDLE)
   {
      Print("Cannot open ", LABELED_FLATDATA_FILENAME,
            ". Error: ", GetLastError());

      return false;
   }

   // Write the header if the file is empty.
   if(FileSize(file) == 0)
   {
      string header = "id,symbol,anchor_price,m1_candle_time";

      AppendLabeledHeaders(header, "M15");
      AppendLabeledHeaders(header, "M5");
      AppendLabeledHeaders(header, "M1");

      if(FileWriteString(file, header + "\r\n") == 0)
      {
         Print("Failed to write labeled CSV header.");
         FileClose(file);
         return false;
      }

      last_labeled_export_id = 0;
   }
   else
   {
      // Recover the last ID after a restart.
      if(!LoadLastLabeledExportID(file))
      {
         Print("Failed to recover the last labeled export ID.");
         FileClose(file);
         return false;
      }
   }

   // Generate the next incremental ID.
   long next_id = last_labeled_export_id + 1;

   // Start the flattened row with metadata.
   string row = IntegerToString(next_id);

   AppendLabeledCSVField(row, _Symbol);

   AppendLabeledCSVField(
      row,
      DoubleToString(anchor_price, _Digits)
   );

   AppendLabeledCSVField(
      row,
      TimeToString(current_m1_time, TIME_DATE | TIME_MINUTES)
   );

   // Append timestamps and normalized OHLC values for every candle.
   AppendLabeledValues(row, labeled_text_15min, real_15min);
   AppendLabeledValues(row, labeled_text_5min, real_5min);
   AppendLabeledValues(row, labeled_text_1min, real_1min);

   // Append the row.
   FileSeek(file, 0, SEEK_END);

   uint written = FileWriteString(file, row + "\r\n");

   FileFlush(file);
   FileClose(file);

   if(written == 0)
   {
      Print("Failed to write labeled CSV row.");
      return false;
   }

   // Update tracking after a successful write.
   last_labeled_export_id = next_id;
   last_labeled_exported_m1_time = current_m1_time;

   Print("Labeled CSV exported: ",
         LABELED_FLATDATA_FILENAME,
         " | ID: ", next_id,
         " | M1 time: ",
         TimeToString(current_m1_time, TIME_DATE | TIME_MINUTES));

   return true;
}

#endif
