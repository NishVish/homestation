
 //+------------------------------------------------------------------+
 //|                                                         Sun.mq5  |
 //+------------------------------------------------------------------+
 #property copyright "Copyright 2026, MetaQuotes Ltd."
 #property link      "https://www.mql5.com"
 #property version   "1.50"
 #property strict

 #define CANDLE_COUNT 20

 #include "variables.mqh"
 #include "data_prep.mqh"
 #include "export_flatdata.mqh"
 #include "export_labeled_flatdata.mqh"

 int OnInit()
 {
    if(!CopyAllData())
    {
       Print("Initial data copy failed. Will retry on the next tick.");
       return INIT_SUCCEEDED;
    }

    ExportFlatData();
    ExportLabeledFlatData();

    return INIT_SUCCEEDED;
 }

 void OnDeinit(const int reason)
 {
 }

 void OnTick()
 {
    if(!CopyAllData())
       return;

    ExportFlatData();
    ExportLabeledFlatData();

    int last = CANDLE_COUNT - 1;

    //Print("Anchor: ", DoubleToString(anchor_price, _Digits),
    //      " | Normalized M1 close: ",
    //      DoubleToString(normalized_1min[last].close, 8),
    //      " | Labeled M1 close: ",
    //      labeled_text_1min[last].close);
 }
