
#property copyright "Copyright 2026, MetaQuotes Ltd."
#property link      "https://www.mql5.com"
#property version   "1.50"
#property strict

#define CANDLE_COUNT 20

#define Export_D1  false
#define Export_H4  true
#define Export_H1  true
#define Export_M15 true
#define Export_M5  true
#define Export_M1  false

#define SnapshotFrequencyMinutes 5

#include "variables.mqh"
#include "data_prep.mqh"
#include "export_flatdata.mqh"
#include "export_labeled_flatdata.mqh"

// Tracks the last processed M5 candle
datetime last_processed_m5_time = 0;

//+------------------------------------------------------------------+
//| Initialization                                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("H4 Export: ", Export_H4);
   Print("H1 Export: ", Export_H1);
   Print("M15 Export: ", Export_M15);
   Print("M5 Export: ", Export_M5);
   Print("M1 Export: ", Export_M1);

   Print("Snapshot frequency: ", SnapshotFrequencyMinutes);

   if(!InitializeLabeledExporter())
      return INIT_FAILED;

   last_processed_m5_time = iTime(_Symbol, PERIOD_M5, 1);

   if(!CopyAllData())
   {
      Print("Initial data copy failed.");
      return INIT_SUCCEEDED;
   }

   ExportFlatData();
   ExportLabeledFlatData();

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Tick                                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   // Get latest completed M5 candle
   datetime current_m5_time = iTime(_Symbol, PERIOD_M5, 1);

   if(current_m5_time == 0)
      return;

   // Process only once per new completed M5 candle
   if(current_m5_time == last_processed_m5_time)
      return;

   // Update tracking
   last_processed_m5_time = current_m5_time;

   // Copy and prepare market data once every 5 minutes
   if(!CopyAllData())
      return;

   // Export
   //ExportFlatData();
   ExportLabeledFlatData();
}
