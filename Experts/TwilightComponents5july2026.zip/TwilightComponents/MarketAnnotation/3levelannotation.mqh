string compareHigh(double a, double b)
{
    if(a > b) return "HH";
    if(a < b) return "LH";
    return "Equal";
}

string compareLow(double a, double b)
{
    if(a > b) return "LL";
    if(a < b) return "HL";
    return "Equal";
}


// 1. Define this struct at the top of your .mqh file
struct LevelResult {
    string levels[];
};

// 2. Change the function to return the Struct type
LevelResult annotateleveldata(ContinuousCandleGroup &data[])
{
    LevelResult res; // This is your internal container
    int size = ArraySize(data);
    if(data[6].direction == "bullish") {
        data[6].levelstatus = "High";
        data[7].levelstatus = "Low";
    } else {

        data[6].levelstatus = "Low";
        data[7].levelstatus = "High";
    }
    if(size > 0 && data[0].direction == "bullish")
    {
        // Use MathMin to prevent "out of range" errors
        for(int i = 0; i <= 4 && i + 2 < size; i += 2)
        {
            data[i].levelstatus = compareHigh(data[i].highestclose, data[i + 2].highestclose);
        }

        for(int i = 1; i <= 5 && i + 2 < size; i += 2)
        {
            data[i].levelstatus = compareLow(data[i].lowestclose, data[i + 2].lowestclose);
        }
    }
    if(size > 0 && data[0].direction == "bearish")
    {
        // Use MathMin to prevent "out of range" errors
        for(int i = 0; i <= 4 && i + 2 < size; i += 2)
        {
            data[i].levelstatus = compareHigh(data[i].lowestclose, data[i + 2].lowestclose);
        }

        for(int i = 1; i <= 5 && i + 2 < size; i += 2)
        {
            data[i].levelstatus = compareLow(data[i].highestclose, data[i + 2].highestclose);
        }
    }
    // 3. Resize the array INSIDE the struct
    ArrayResize(res.levels, size);

    for(int i = 0; i < size; i++)
    {
        res.levels[i] = data[i].levelstatus;

        Print(res.levels[i]);
    }

    // 4. Return the struct variable
    return res;
}


void PrintGroupSingle(ContinuousCandleGroup &g, int index = 0)
{
    Print("Group #", index,
    " HighestHigh: ", g.highesthigh,
    " HighestHighTime: ", TimeToString(g.highesthightime),

    " HighestClose: ", g.highestclose,
    " HighestCloseTime: ", TimeToString(g.highestclosetime),

    " SecondHighestHigh: ", g.secondhighesthigh,
    " SecondHighestClose: ", g.secondhighestclose,

    " LowestLow: ", g.lowestlow,
    " LowestLowTime: ", TimeToString(g.lowestlowtime),

    " LowestClose: ", g.lowestclose,
    " LowestCloseTime: ", TimeToString(g.lowestclosetime),

    " SecondLowestLow: ", g.secondlowestlow,
    " SecondLowestClose: ", g.secondlowestclose,

    " Direction: ", g.direction,
    " Group ID: ", g.groupid,
    " Count: ", g.count,
    " Level: ", g.levelstatus
    );
}

void PrintGroups(ContinuousCandleGroup &data[])
{
    for(int i = 0; i < ArraySize(data); i++)
    {
        Print("Group #", i,
        " HighestHigh: ", data[i].highesthigh,
        " HighestHighTime: ", TimeToString(data[i].highesthightime),

        " HighestClose: ", data[i].highestclose,
        " HighestCloseTime: ", TimeToString(data[i].highestclosetime),

        " SecondHighestHigh: ", data[i].secondhighesthigh,
        " SecondHighestClose: ", data[i].secondhighestclose,

        " LowestLow: ", data[i].lowestlow,
        " LowestLowTime: ", TimeToString(data[i].lowestlowtime),

        " LowestClose: ", data[i].lowestclose,
        " LowestCloseTime: ", TimeToString(data[i].lowestclosetime),

        " SecondLowestLow: ", data[i].secondlowestlow,
        " SecondLowestClose: ", data[i].secondlowestclose,

        " Direction: ", data[i].direction,
        " Group ID: ", data[i].groupid,
        " Count: ", data[i].count,
        " Level: ", data[i].levelstatus
        );
    }
}