

struct countiniouscandlegroup {
   double highesthigh;
   datetime highesthightime;
   
   double highestclose;
   datetime highestclosetime;
   
   double secondhighesthigh;
   datetime secondhighesthightime;
   
   double secondhighestclose;
   datetime secondhighestclosetime;
   
   double lowestlow;
   datetime lowestlowtime;
   
   double lowestclose;
   datetime lowestclosetime;
   
   double secondlowestlow;
   datetime secondlowestlowtime;
   
   double secondlowestclose;
   datetime secondlowestclosetime;
   
   string direction;
   int groupid;
   int count;
   string levelstatus;
};

countiniouscandlegroup fourhourgroupdata[], onehourgroupdata[], fifteenmingroupdata[];

void GetContinuousGroupData(const rawdata &data[], countiniouscandlegroup &result) {
   int total = ArraySize(data);
   if(total == 0) return;

   // Initialize numeric values with extremes to ensure first comparison works
   result.highesthigh = -1.0;
   result.highestclose = -1.0;
   result.secondhighesthigh = -1.0;
   result.secondhighestclose = -1.0;
   
   result.lowestlow = 1000000.0; // Arbitrary high number
   result.lowestclose = 1000000.0;
   result.secondlowestlow = 1000000.0;
   result.secondlowestclose = 1000000.0;
   
   result.count = total;
   result.direction = data[0].direction; // Assuming direction is consistent for the group

   for(int i = 0; i < GROUP_LENGTH; i++) {
      
      // --- Highs Logic ---
      if(data[i].high > result.highesthigh) {
         result.secondhighesthigh = result.highesthigh;
         result.secondhighesthightime = result.highesthightime;
         
         result.highesthigh = data[i].high;
         result.highesthightime = data[i].time;
      } else if(data[i].high > result.secondhighesthigh) {
         result.secondhighesthigh = data[i].high;
         result.secondhighesthightime = data[i].time;
      }

      // --- Highest Close Logic ---
      if(data[i].close > result.highestclose) {
         result.secondhighestclose = result.highestclose;
         result.secondhighestclosetime = result.highestclosetime;
         
         result.highestclose = data[i].close;
         result.highestclosetime = data[i].time;
      } else if(data[i].close > result.secondhighestclose) {
         result.secondhighestclose = data[i].close;
         result.secondhighestclosetime = data[i].time;
      }

      // --- Lows Logic ---
      if(data[i].low < result.lowestlow) {
         result.secondlowestlow = result.lowestlow;
         result.secondlowestlowtime = result.lowestlowtime;
         
         result.lowestlow = data[i].low;
         result.lowestlowtime = data[i].time;
      } else if(data[i].low < result.secondlowestlow) {
         result.secondlowestlow = data[i].low;
         result.secondlowestlowtime = data[i].time;
      }

      // --- Lowest Close Logic ---
      if(data[i].close < result.lowestclose) {
         result.secondlowestclose = result.lowestclose;
         result.secondlowestclosetime = result.lowestclosetime;
         
         result.lowestclose = data[i].close;
         result.lowestclosetime = data[i].time;
      } else if(data[i].close < result.secondlowestclose) {
         result.secondlowestclose = data[i].close;
         result.secondlowestclosetime = data[i].time;
      }
      result.groupid = data[i].groupid;
   }
}