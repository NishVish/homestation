
// Fetch Data
int fetchRawData(MqlRates &rates[], ENUM_TIMEFRAMES period)
{
    ArraySetAsSeries(rates, true);
    int copied = CopyRates(_Symbol, period, 1, candletoworkwith, rates);

    if(copied <= 0)
    {
        Print("CopyRates failed for: ", EnumToString(period), " Error: ", GetLastError());
    }
    return copied;
}



// Process Candle Type + Grouping
int SetCandleDirectionandGroupid(const MqlRates &rates[], rawdata &out[]) {
    int length = ArraySize(rates);
    if(length == 0)
    return 0;

    ArrayResize(out, length);

    int groupidcount = 1; // reset every call(IMPORTANT)
    string lastgrouptype = "";

    for(int i = 0; i < length; i++)
    {
        // Copy OHLC
        out[i].time = rates[i].time;
        out[i].open = rates[i].open;
        out[i].high = rates[i].high;
        out[i].low = rates[i].low;
        out[i].close = rates[i].close;

        // Direction
        if(rates[i].close > rates[i].open)
        out[i].direction = "bullish";
        else if(rates[i].close < rates[i].open)
        out[i].direction = "bearish";
        else
        out[i].direction = "neutral";

        // Grouping logic
        if(i == 0)
        {
            out[i].groupid = groupidcount;
            lastgrouptype = out[i].direction;
            continue;
        }

        if(out[i].direction != lastgrouptype)
        {
            groupidcount++;
            lastgrouptype = out[i].direction;
        }

        out[i].groupid = groupidcount;
    }

    return length;
}

