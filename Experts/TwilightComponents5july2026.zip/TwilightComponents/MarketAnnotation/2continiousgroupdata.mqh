

void GetContinuousGroupData(const rawdata &data[], ContinuousCandleGroup &result[])
{
    int totalBars = ArraySize(data);
    if(totalBars == 0) return;

    ArrayResize(result, 8);
    int resIdx = 0;
    const int MAX_GROUPS = 8;
    
    for(int i = 0; i < totalBars && resIdx < MAX_GROUPS; i++)
    {
        // --- 1. RESET PARAMETERS FOR NEW GROUP ---
        result[resIdx].highesthigh = - DBL_MAX;
        result[resIdx].highestclose = - DBL_MAX;
        result[resIdx].secondhighesthigh = - DBL_MAX;
        result[resIdx].secondhighestclose = - DBL_MAX;

        result[resIdx].lowestlow = DBL_MAX;
        result[resIdx].lowestclose = DBL_MAX;
        result[resIdx].secondlowestlow = DBL_MAX;
        result[resIdx].secondlowestclose = DBL_MAX;

        result[resIdx].direction = data[i].direction;
        result[resIdx].groupid = data[i].groupid;
        result[resIdx].count = 0;

        // --- GROUP OPEN: first candle's open ---
        result[resIdx].open = data[i].open;
        result[resIdx].high = - DBL_MAX;
        result[resIdx].low = DBL_MAX;
        result[resIdx].close = 0; // will be overwritten each bar; last bar wins

        int j = i;
        // --- 2. ACCUMULATE DATA FOR CONTINUOUS DIRECTION ---
        while(j < totalBars && data[j].direction == result[resIdx].direction)
        {
            // --- GROUP HIGH: highest high across all candles in group ---
            if(data[j].high > result[resIdx].high)
            result[resIdx].high = data[j].high;

            // --- GROUP LOW: lowest low across all candles in group ---
            if(data[j].low < result[resIdx].low)
            result[resIdx].low = data[j].low;

            // --- GROUP CLOSE: close of the last candle in the group ---
            result[resIdx].close = data[j].close;

            // Update Highest High & Second Highest High
            if(data[j].high > result[resIdx].highesthigh) {
                result[resIdx].secondhighesthigh = result[resIdx].highesthigh;
                result[resIdx].highesthigh = data[j].high;
                result[resIdx].highesthightime = data[j].time;
            } else if (data[j].high > result[resIdx].secondhighesthigh) {
                result[resIdx].secondhighesthigh = data[j].high;
            }

            // Update Highest Close & Second Highest Close
            if(data[j].close > result[resIdx].highestclose) {
                result[resIdx].secondhighestclose = result[resIdx].highestclose;
                result[resIdx].highestclose = data[j].close;
                result[resIdx].highestclosetime = data[j].time;
            } else if (data[j].close > result[resIdx].secondhighestclose) {
                result[resIdx].secondhighestclose = data[j].close;
            }

            // Update Lowest Low & Second Lowest Low
            if(data[j].low < result[resIdx].lowestlow) {
                result[resIdx].secondlowestlow = result[resIdx].lowestlow;
                result[resIdx].lowestlow = data[j].low;
                result[resIdx].lowestlowtime = data[j].time;
            } else if (data[j].low < result[resIdx].secondlowestlow) {
                result[resIdx].secondlowestlow = data[j].low;
            }

            // Update Lowest Close & Second Lowest Close
            if(data[j].close < result[resIdx].lowestclose) {
                result[resIdx].secondlowestclose = result[resIdx].lowestclose;
                result[resIdx].lowestclose = data[j].close;
                result[resIdx].lowestclosetime = data[j].time;
            } else if (data[j].close < result[resIdx].secondlowestclose) {
                result[resIdx].secondlowestclose = data[j].close;
            }

            result[resIdx].count++;
            j++;
        }

        i = j - 1;
        resIdx++;
    }

    ArrayResize(result, resIdx);
}