


//====================================================
// MetaTrader Includes
//====================================================

#include <Trade/Trade.mqh>

CTrade trade;


//====================================================
// Global Inputs & Data Structures
//====================================================

#include "Variables/input.mqh"
#include "Variables/dataTypes.mqh"


//====================================================
// Market Data Collection
// Fetch raw candle data from multiple timeframes
//====================================================

#include "MarketAnnotation/1fetchrawdata.mqh"


//====================================================
// Market Structure Annotation
// Continuous groups, levels, zones, etc.
//====================================================

#include "MarketAnnotation/2continiousgroupdata.mqh"
#include "MarketAnnotation/3levelannotation.mqh"
// #include "MarketAnnotation/groupleveldata.mqh"


//====================================================
// Market Analysis Engine
// Generates higher-level market context
//====================================================

#include "MarketAnalysis/5maketanalysis.mqh"


//====================================================
// Export / Dataset Generation
// Feature matrices, training data, trade logs
//====================================================

#include "ExportData/generatefile.mqh"
#include "ExportData/MultiMatrix.mqh"
#include "ExportData/TradeOutcome.mqh"
#include "ExportData/OrderData.mqh"


//====================================================
// Order Execution & Management
//====================================================

#include "Order/Order.mqh"
#include "Order/MakeOrder.mqh"
#include "Order/StoreOrderData.mqh"


//====================================================
// Debugging & Visualization
//====================================================

#include "Print/4print.mqh"


//====================================================
// Data Syncing
//====================================================

#include "DataSync/datasync.mqh"
