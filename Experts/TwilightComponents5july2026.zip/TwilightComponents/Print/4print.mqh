
void PrintData()
{
      Print(fetchRawData(fourhour, PERIOD_H4));

      int count = 0;

      for(int i = 0; i < ArraySize(fourhour); i++)
        {
         count++;

         Print("Candle #", i,
               " Time: ", fourhour[i].time,
               " O: ", fourhour[i].open,
               " H: ", fourhour[i].high,
               " L: ", fourhour[i].low,
               " C: ", fourhour[i].close);
        }

      Print("Total candles = ", count);

      for(int i = 0; i < ArraySize(fourhourrawdata); i++)
        {
         Print("Candle #", i,
               " Time: ", fourhourrawdata[i].time,
               " O: ", fourhourrawdata[i].open,
               " H: ", fourhourrawdata[i].high,
               " L: ", fourhourrawdata[i].low,
               " C: ", fourhourrawdata[i].close,
               " Direction: ", fourhourrawdata[i].direction,
               " Group ID: ", fourhourrawdata[i].groupid);
        }

      for(int i = 0; i < ArraySize(fourhourgroupdata); i++)
        {
         Print("Group #", i,
               " HighestHigh: ", fourhourgroupdata[i].highesthigh,
               " HighestHighTime: ", TimeToString(fourhourgroupdata[i].highesthightime),

               " HighestClose: ", fourhourgroupdata[i].highestclose,
               " HighestCloseTime: ", TimeToString(fourhourgroupdata[i].highestclosetime),

               " SecondHighestHigh: ", fourhourgroupdata[i].secondhighesthigh,
               " SecondHighestClose: ", fourhourgroupdata[i].secondhighestclose,

               " LowestLow: ", fourhourgroupdata[i].lowestlow,
               " LowestLowTime: ", TimeToString(fourhourgroupdata[i].lowestlowtime),

               " LowestClose: ", fourhourgroupdata[i].lowestclose,
               " LowestCloseTime: ", TimeToString(fourhourgroupdata[i].lowestclosetime),

               " SecondLowestLow: ", fourhourgroupdata[i].secondlowestlow,
               " SecondLowestClose: ", fourhourgroupdata[i].secondlowestclose,

               " Direction: ", fourhourgroupdata[i].direction,
               " Group ID: ", fourhourgroupdata[i].groupid,
               " Count: ", fourhourgroupdata[i].count,
               " Level: ", fourhourgroupdata[i].levelstatus
              );
        }

}