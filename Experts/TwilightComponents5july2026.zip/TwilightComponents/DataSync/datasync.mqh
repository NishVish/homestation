////
////
////
////struct rawdata
////{
////    datetime time;
////    double open;
////    double high;
////    double low;
////    double close;
////    string direction;
////    int groupid;
////};
////
////rawdata fourhourrawdata[], onehourrawdata[], fifteenminrawdata[];
//
//
//

void DataSync()
{

  rawdata onehourdata = onehourrawdata[0];

  rawdata lastentry       = fifteenminrawdata[0];
  rawdata secondlastentry = fifteenminrawdata[1];
  rawdata thirdlastentry  = fifteenminrawdata[2];
  rawdata fourthlastentry = fifteenminrawdata[3];

   // If the current H1 candle is not yet available,
   // use the previous completed H1 candle.
   if(onehourdata.time == secondlastentry.time)
      onehourdata = secondlastentry;

   // -----------------------------------------
   // Count how many M15 candles belong to
   // the current H1 candle.
   // -----------------------------------------

   int candlesMade = 0;

   if(lastentry.time >= onehourdata.time)
      candlesMade++;

   if(secondlastentry.time >= onehourdata.time)
      candlesMade++;

   if(thirdlastentry.time >= onehourdata.time)
      candlesMade++;

   if(fourthlastentry.time >= onehourdata.time)
      candlesMade++;

   // -----------------------------------------
   // Start with latest candle
   // -----------------------------------------

   double high = lastentry.high;
   double low  = lastentry.low;
   double close = lastentry.close;

   // Add more candles depending on progress
   if(candlesMade >= 2)
   {
      high = MathMax(high, secondlastentry.high);
      low  = MathMin(low, secondlastentry.low);
   }

   if(candlesMade >= 3)
   {
      high = MathMax(high, thirdlastentry.high);
      low  = MathMin(low, thirdlastentry.low);
   }

   if(candlesMade >= 4)
   {
      high = MathMax(high, fourthlastentry.high);
      low  = MathMin(low, fourthlastentry.low);
   }

   onehourdata.high  = high;
   onehourdata.low   = low;
   onehourdata.close = close;

  double rangeintermof1hour = high - low;
}


//void DataSync()
//{
//
//
//   onehourdata = onehourrawdata[0];
//   
//   
//   lastentry = fifteenminrawdata[0];
//   secondlastentry= fifteenminrawdata[1];
//   thirdlastentry = fifteenminrawdata[2];
//   fourthlastentry = fifteenminrawdata[3];
//   
//
//if(onehourdata.time == secondlastentry.time){
//
//   onehourdata = secondlastentry
//
//}
//
//rangeintermof1hour = 0 ;
//
//if only 1/4 for one candle is made only use last entry 
//
//if only 2/4 for one candle is made  use [lastentry secondlastentry] 
//to get high and low
//
//if only 3/4 for one candle is made  use [lastentry secondlastentry,thirdlastentry] 
//to get high and low
//
//if only 4/4 for one candle is made  use [lastentry secondlastentry,thirdlastentry,fourthlastentry] 
//to get high and low
//
//
//
//
//if(onehourdata.time < secondlastentry.time){
//
//and the difference is 15min 
//
//
//   onehourdata.high = secondlastentry
//
//   onehourdata.low
//   
//   onehourdata.close
//}
//
//
//
//}





















//
//
//
//
//void DataSync(rawdata &higher[], rawdata &lower[])
//{
//
//   rawdata lastentry = lower[0];
//   rawdata secondlastentry= lower[1];
//   rawdata thirdlastentry = lower[2];
//   rawdata fourthlastentry = lower[2];
//   
//   rawdata lastentryhighertf = higher[0];
//   
//   
//get first entry of both 
//
//if highet tf = 1 oclco 
//and lowertimegrae = 1:15 
//
//it mean only one candle has formed 
//
//so hihgher.low = lower.low
//higher.high = lower.high
//higher.close = lower.close
//
//
//if higher.time = 1 and lower.time = 1:45 means
//so hihgher.low = lower.low(in last 3)
//higher.high = lower.high(in last 3)
//higher.close = lower.close
//
//}
//
//}


//
// DataSync(onehourrawdata, fifteenminrawdata);
// DataSync(fourhourrawdata, onehourrawdata);