//+------------------------------------------------------------------+
//|                                                     Twilight.mq5 |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Nishant Vishwakarma"
#property link      "https://nishvish.github.io/nishvish/"
#property version   "1.00"

#property strict


#include "TwilightComponents/engine.mqh"
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+


void OnInit()
{

    //runviusals(true);
    //analysis();
   
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
}
datetime lastM15Time = 0;
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
    datetime currentM15Time = iTime(_Symbol, PERIOD_M15, 0);

    if(currentM15Time != lastM15Time)
    {
        lastM15Time = currentM15Time;
        // bool analysis = true;

        Analysis();
        makeorders();
    }

}

// void OnDeinit(const int reason)
// {
//     ExportTradeJournal();
// }
double OnTester()
{

    Print("file_exported");
    //ExportTradeJournal();
    //ExportTradeJournalcsv();
    // ExportOpenTradeData();
    // ExportTradeOutcomeData();
    return 0.0;
}
